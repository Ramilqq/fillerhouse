<?php
define('MODX_API_MODE', true);
/** @noinspection PhpIncludeInspection */
require dirname(dirname(dirname(dirname(dirname(__FILE__))))) . '/index.php';

/** @var modX $modx */
$modx->getService('error', 'error.modError');
$modx->setLogLevel(modX::LOG_LEVEL_ERROR);
$modx->setLogTarget('FILE');

/** @var miniShop2 $miniShop2 */
$miniShop2 = $modx->getService('miniShop2');
$miniShop2->loadCustomClasses('payment');

if (!class_exists('Venmo')) {
    exit('Error: could not load payment class "Venmo".');
}
/** @var msOrder $order */
$order = $modx->newObject('msOrder');
/** @var msPaymentInterface|Venmo $handler */
$handler = new Venmo($order);

if (isset($_GET['action']) && $_GET['action'] == 'repay' && !empty($_GET['msorder']) && !empty($_GET['mscode'])) {
    if ($order = $modx->getObject('msOrder', (int)$_GET['msorder'])) {
        if ($_GET['mscode'] == $handler->getOrderHash($order)) {
            $response = $handler->send($order);
            if ($response['success'] && !empty($response['data']['redirect'])) {
                $order->set('payment', 18);
                $order->set('status', 1);
                $order->save();
                $modx->sendRedirect($response['data']['redirect']);
            } else {
                exit($response['message']);
            }
        }
    }
    exit('Error when continuing order');
}

$context = '';
$params = array();


if ($modx->context->key !== $context && !empty($context)) {
    $modx->switchContext($context);
}

$success = $cancel = $modx->getOption('site_url');
if ($id = $modx->getOption('ms2_payment_Venmo_success_id', null, 0)) {
    $success = $modx->makeUrl($id, $context, $params, 'full');
}
if ($id = $modx->getOption('ms2_payment_Venmo_cancel_id', null, 0)) {
    $cancel = $modx->makeUrl($id, $context, $params, 'full');
}

$redirect = !empty($_GET['action']) && $_GET['action'] == 'success'
    ? $success
    : $cancel;
$modx->sendRedirect($redirect);
