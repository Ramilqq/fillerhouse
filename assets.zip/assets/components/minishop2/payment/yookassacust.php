<?php

define('MODX_API_MODE', true);

require dirname(dirname(dirname(dirname(dirname(__FILE__))))) . '/index.php';

$modx->getService('error', 'error.modError');
$modx->setLogLevel(modX::LOG_LEVEL_ERROR);
$modx->setLogTarget('FILE');

$miniShop2 = $modx->getService('minishop2');
$miniShop2->loadCustomClasses('payment');

$source = file_get_contents('php://input');
$json = json_decode($source, true);

$modx->log(modX::LOG_LEVEL_ERROR, '[============================================================================================');
$modx->log(modX::LOG_LEVEL_ERROR, '[miniShop2:Yookassacust] respons json '. print_r($json,1));
$modx->log(modX::LOG_LEVEL_ERROR, '[miniShop2:Yookassacust] respons json '. print_r($_REQUEST,1));
$modx->log(modX::LOG_LEVEL_ERROR, '[============================================================================================');

if (!class_exists('Yookassacust')) {exit('Error: could not load payment class "Yookassacust".');}

$params = array();

/* @var msPaymentInterface|Yookassacust $handler */
$handler = new Yookassacust($modx->newObject('msOrder'));
//pending, waiting_for_capture, succeeded и canceled
if ($_REQUEST['action'] == 'yookassa' and $json['object']['id'] and strripos($json['event'],'refund')!== false) {
    if ($order = $modx->getObject('msOrder', $json['object']['description'])) {
		$handler->sendOrder($order, $json);
	}
}elseif ($_REQUEST['action'] == 'yookassa' and $json['object']['id'] and $json['object']['metadata']['orderId'] and strripos($json['event'],'payment')!== false) {
	if ($order = $modx->getObject('msOrder', $json['object']['metadata']['orderId'])) {
		$handler->sendOrder($order, $json);
	}
}elseif ($_REQUEST['action'] == 'recontinue' and !empty($_REQUEST['msorder']) and !empty($_REQUEST['mscode'])) {
	if ($order = $modx->getObject('msOrder', (int)$_REQUEST['msorder'])) {
        if ($_REQUEST['mscode'] == $handler->getOrderHash($order)) {
            $response = $handler->send($order);
            if ($response['success'] && !empty($response['data']['redirect'])) {
                $modx->sendRedirect($response['data']['redirect']);
            } else {
                exit($response['message']);
            }
        }
    }
}else {
	$modx->log(modX::LOG_LEVEL_ERROR, '[miniShop2:Yookassacust] err');
}

return true;