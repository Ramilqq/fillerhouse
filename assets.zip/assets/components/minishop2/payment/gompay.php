<?php
define('MODX_API_MODE', true);
require dirname(dirname(dirname(dirname(dirname(__FILE__))))) . '/index.php';

$modx->getService('error','error.modError');
$modx->setLogLevel(modX::LOG_LEVEL_ERROR);
$modx->setLogTarget('FILE');

//$modx->log(modX::LOG_LEVEL_ERROR, '[============================================================================================');
//$modx->log(modX::LOG_LEVEL_ERROR, '[miniShop2:Gompay] requst '. print_r($_REQUEST,1));
//$modx->log(modX::LOG_LEVEL_ERROR, '[============================================================================================');

/* @var miniShop2 $miniShop2 */
$miniShop2 = $modx->getService('minishop2');
$miniShop2->loadCustomClasses('payment');

if (!class_exists('Gompay')) {exit('Error: could not load payment class "Gompay".');}
$context = '';
$params = array();

/* @var msPaymentInterface|Gompay $handler */
$handler = new Gompay($modx->newObject('msOrder'));

if ($_GET['action'] == '3dsecure' and $_REQUEST['order_id'] == $_SESSION['orderNum'] and $_REQUEST['amount'] == $_SESSION['amount']) {
	if ($order = $modx->getObject('msOrder', $_SESSION['orderId'])) {
		$handler->sendOrder($order, $_REQUEST);
        $params['msorder'] = $order->get('id');
	}
	else {
		$modx->log(modX::LOG_LEVEL_ERROR, '[miniShop2:Gompay] Could not retrieve order with id '.$_REQUEST['LMI_PAYMENT_NO']);
	}
}

//rePay
if (isset($_GET['action']) && $_GET['action'] == 'continue' && !empty($_GET['msorder']) && !empty($_GET['mscode'])) {
    if ($order = $modx->getObject('msOrder', (int)$_GET['msorder'])) {
        if ($_GET['mscode'] == $handler->getOrderHash($order)) {
            $response = $handler->send($order);
            if ($response['success'] && !empty($response['data']['redirect'])) {
                $modx->sendRedirect($response['data']['redirect']);
            } else {
                exit($response['message']);
            }
        }
    }
    exit('Error when continuing order');
}


if ($modx->context->key !== $context && !empty($context)) {
    $modx->switchContext($context);
}

if (!empty($_SESSION['orderId'])) {$params['msorder'] = $_SESSION['orderId'];}

$success = $failure = $modx->getOption('site_url');

//if ($id = $modx->getOption('ms2_payment_gompay_success_id', 6, 0)) {
	$success = $modx->makeUrl(6, $context, $params, 'full');
//}
//if ($id = $modx->getOption('ms2_payment_gompay_failure_id', 6, 0)) {
	$failure = $modx->makeUrl(6, $context, $params, 'full');
//}

$redirect = !empty($_REQUEST['action']) && $_REQUEST['action'] == '3dsecure' ? $success : $failure;

header('Location: ' . $redirect);
