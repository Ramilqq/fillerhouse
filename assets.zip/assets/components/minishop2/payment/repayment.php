<?php

define('MODX_API_MODE', true);
/** @noinspection PhpIncludeInspection */
require dirname(dirname(dirname(dirname(dirname(__FILE__))))) . '/index.php';

/** @var modX $modx */
$modx->getService('error', 'error.modError');
$modx->setLogLevel(modX::LOG_LEVEL_ERROR);
$modx->setLogTarget('FILE');

/** @var miniShop2 $miniShop2 */
$miniShop2 = $modx->getService('miniShop2');
$miniShop2->loadCustomClasses('payment');

$context = '';
$params = array();

if (!class_exists('PayPal')) {
    exit('Error: could not load payment class "PayPal".');
}
if ($_REQUEST['payment'] == '17' and $_SESSION['orderId']){
    exit;
    $order = $modx->newObject('msOrder');
    $handler = new Yookassacust($order);
    if ($order = $modx->getObject('msOrder', (int)$_SESSION['orderId'])) {
        $order->set('payment', 17);
        $order->save();
        $handler->send($order);
    }
    
}
if ($_REQUEST['payment'] == '18' and $_REQUEST['msorder']){
    $order = $modx->newObject('msOrder');
    $handler = new Venmo($order);
    if ($order = $modx->getObject('msOrder', (int)$_REQUEST['msorder'])) {
        if ($order->get('status') != 2) {
            $order->set('payment', 18);
            $order->set('status', 1);
            $order->save();
            $resault = $handler->send($order);
            
            $success = $failure = $resault['data']['redirect'];
            //$redirect = $succes  . '?' .  http_build_query(array('msorder' => $order->get('id')));
            $redirect = $success;
            header('Location: ' . $redirect);
        }
    }
}
