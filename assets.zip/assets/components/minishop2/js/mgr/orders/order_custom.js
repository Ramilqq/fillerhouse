miniShop2.grid.Orders = function (config) {
    miniShop2.grid.Orders.superclass.constructor.call(this, config);
};
Ext.extend(miniShop2.grid.Orders, miniShop2.grid.Default, {

});