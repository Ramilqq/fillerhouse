miniShop2.plugin.msfieldsmanager = {
	getFields: function(config) {
		return {
			in_remains: {
				xtype: 'xcheckbox'
				,hideLabel: true 
				,inputValue: 1 
				,checked:  msfmRecord['in_remains'] ? true : false 
				,boxLabel: _('ms2_product_in_remains')
				,fieldLabel: _('ms2_product_in_remains')
				,description: '<b>[[*in_remains]]</b><br />'+_('ms2_product_in_remains_help')
				,name: 'in_remains'
				,value: msfmRecord['in_remains']
				,allowBlank:true
				,anchor: '100%'
			},
			boxes: {
				xtype: 'minishop2-combo-options'
				,fieldLabel: _('ms2_product_boxes')
				,description: '<b>[[*boxes]]</b><br />'+_('ms2_product_boxes_help')
				,name: 'boxes'
				,value: msfmRecord['boxes']
				,allowBlank:true
				,anchor: '100%'
			},
			ms_type: {
				xtype: 'minishop2-combo-options'
				,fieldLabel: _('ms2_product_ms_type')
				,description: '<b>[[*ms_type]]</b><br />'+_('ms2_product_ms_type_help')
				,name: 'ms_type'
				,value: msfmRecord['ms_type']
				,allowBlank:true
				,anchor: '100%'
			}
		}
	},
	getColumns: function() {
		return {
			in_remains: {
				header: _('ms2_product_in_remains')
				,dataIndex: 'in_remains'
				,name: 'in_remains'
				,width: 60
				,editor: {
					xtype: 'xcheckbox'
					,renderer: 'boolean'
				}
			},
			boxes: {
				header: _('ms2_product_boxes')
				,dataIndex: 'boxes'
				,name: 'boxes'
				,editor: {
					xtype: 'minishop2-combo-options'
				}
			},
			ms_type: {
				header: _('ms2_product_ms_type')
				,dataIndex: 'ms_type'
				,name: 'ms_type'
				,editor: {
					xtype: 'minishop2-combo-options'
				}
			}
		}
	}
};