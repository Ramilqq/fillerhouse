tazapay.page.Home = function (config) {
    config = config || {};
    Ext.applyIf(config, {
        components: [{
            xtype: 'tazapay-panel-home',
            renderTo: 'tazapay-panel-home-div'
        }]
    });
    tazapay.page.Home.superclass.constructor.call(this, config);
};
Ext.extend(tazapay.page.Home, MODx.Component);
Ext.reg('tazapay-page-home', tazapay.page.Home);