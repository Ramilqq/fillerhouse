var tazapay = function (config) {
    config = config || {};
    tazapay.superclass.constructor.call(this, config);
};
Ext.extend(tazapay, Ext.Component, {
    page: {}, window: {}, grid: {}, tree: {}, panel: {}, combo: {}, config: {}, view: {}, utils: {}
});
Ext.reg('tazapay', tazapay);

tazapay = new tazapay();