/*-------------------------------------------------------------------------------------------------
FILE NAME	: gompay.js
AUTHOR		: GOM Inc Technical Support Team, support@gominc.com
DATE		: 2022-07-01

http:www.gompay.net
Copyright (c) 2013 GOMInc Co., Ltd. All Rights Reserved.
--------------------------------------------------------------------------------------------------*/

// 3D Secure authentication form
var formGompay3DS = null;
// 3D Secure authentication popup window
var popupGompay3DS = null;

function doGompay(){
	try {
		if(popupGompay3DS == null || popupGompay3DS.closed){
			setFormGompay3DS();
		    
		    console.log(formGompay3DS);
		    let card = Number(formGompay3DS.card_number.value);
		    let month = Number(formGompay3DS.expiry_month.value);
		    let year = Number(formGompay3DS.expiry_year.value);
		    //let cvv = Number(formGompay3DS.card_cvv.value);
		    //let holder = formGompay3DS.card_holder.value;
		    
		    let validate = 0
		    console.log(formGompay3DS);
		    
		    if ( card.length < 12 | card.length > 16 ){
		        let card_number_error = document.getElementsByClassName("card_number_error");
		        card_number_error[0].innerHTML = "The field is entered incorrectly. Min 12, max 16 symbols";
		        validate = validate + 1;
		    }else{
		        let card_number_error = document.getElementsByClassName("card_number_error");
		        card_number_error[0].innerHTML = "";
		    }
		    
		    if (month == null | month == 0 | month > 12){
		        let expiry_month_error = document.getElementsByClassName("expiry_month_error");
		        expiry_month_error[0].innerHTML = "The field is entered incorrectly";
		        validate = validate + 1;
		    }else{
		        let expiry_month_error = document.getElementsByClassName("expiry_month_error");
		        expiry_month_error[0].innerHTML = "";
		    }
		    
		    if ( year < 2022 | year > 2052 ){
		        let expiry_year_error = document.getElementsByClassName("expiry_year_error");
		        expiry_year_error[0].innerHTML = "The field is entered incorrectly. Format YYYY.";
		        validate = validate + 1;
		    }else{
		        let expiry_year_error = document.getElementsByClassName("expiry_year_error");
		        expiry_year_error[0].innerHTML = "";
		    }
		    
		    /*if ( cvv == 0 ){
		        let card_cvv_error = document.getElementsByClassName("card_cvv_error");
		        card_cvv_error[0].innerHTML = "The field is entered incorrectly.";
		        validate = validate + 1;
		    }else{
		        let card_cvv_error = document.getElementsByClassName("card_cvv_error");
		        card_cvv_error[0].innerHTML = "";
		    }*/
		    
		    /*if ( holder.length == 0 ){
		        let card_holder_error = document.getElementsByClassName("card_holder_error");
		        card_holder_error[0].innerHTML = "The field is entered incorrectly.";
		        validate = validate + 1;
		    }else{
		        let card_holder_error = document.getElementsByClassName("card_holder_error");
		        card_holder_error[0].innerHTML = "";
		    }*/
		    
		    
		    if (validate == 0){
		        setPopupGompay3DS();
		        formGompay3DS.target = popupGompay3DS.name;
		        formGompay3DS.submit();
		    }
		} else {
			popupGompay3DS.focus();
		}
	} catch (e) {
		alert(e);
	}
}

// Create 3D Secure authentication form
function setFormGompay3DS(){
    formGompay3DS = document.getElementById("formGompay3DS");
    
    if( formGompay3DS == null) {
        formGompay3DS = document.createElement("form");
        formGompay3DS.setAttribute("name", "formGompay3DS");
        formGompay3DS.setAttribute("id", "formGompay3DS");
        formGompay3DS.setAttribute("charset", "UTF-8");
        formGompay3DS.setAttribute("method", "post");
        var request_url = location.href;
        //request_url = request_url.substring(0, request_url.lastIndexOf('/')) + '/request.php';
        //formGompay3DS.setAttribute("action", request_url);
        formGompay3DS.setAttribute("action", "/action/g_secure_check.php");
        formGompay3DS.setAttribute("target", "popupGompay3DS");
    } else {
        while ( formGompay3DS.hasChildNodes() ) {
            formGompay3DS.removeChild( formGompay3DS.firstChild );
        }
    }

    // In the version, 1 is a fixed value.
    var input = document.createElement("input");
    input.setAttribute("type", "hidden");
    input.setAttribute("name", "version");
    input.setAttribute("value", "2");
    formGompay3DS.appendChild(input);

	// Apply the payment form value.
    var array = ['merchant_id','order_id','amount','card_number','expiry_month','expiry_year','currency_code'];
    for(var i=0; i<array.length; i++) {
        input = document.createElement("input");
        input.setAttribute("type", "hidden");
        input.setAttribute("name", document.getElementById(array[i]).name);
        input.setAttribute("value", document.getElementById(array[i]).value);
        formGompay3DS.appendChild(input);
    }

	// The url that will return the 3d authentication result is applied according to the merchant environment.
    var return_url = location.href;
    return_url = return_url.substring(0, return_url.lastIndexOf('/')) + '/assets/components/gompay/return.php';
    input = document.createElement("input");
    input.setAttribute("type", "hidden");
    input.setAttribute("name", "return_url");
    input.setAttribute("value", return_url);
    formGompay3DS.appendChild(input);
    document.body.appendChild(formGompay3DS);
}

// Create 3D Secure authentication popup window
function setPopupGompay3DS (){
  var popupWidth = 700;
	var popupHeight = 620;
	var winX = window.screenLeft;
	var winY = window.screenTop;
	var winWidth = document.body.clientWidth;
	var winHeight = screen.availHeight + 15;

	var popupX = winX + (winWidth - popupWidth) / 2;
	var popupY = (winHeight - popupHeight) / 2;

	var option = "";
	option += "left=" + popupX + "px,";
	option += "top=" + popupY + "px,";
	option += "width=" + popupWidth + "px,";
	option += "height=" + popupHeight + "px,";
	option += "toolbar=no,menubar=no,location=no,";
	option += "resizable=yes,status=yes";

	// popupGompay3DS = window.open("about:blank", "popupGompay3DS", option);
	popupGompay3DS = window.open("", "popupGompay3DS",option);
}

// Used in return page
var checkGompayRequest = false;

function doPayment(status, xid, eci, cavv, gid){
	if(checkGompayRequest){
		alert("Payment is being processed. Please wait");
		return false;
	} else {
		if(status == "SUCCESS") {
			checkGompayRequest = true;
			document.getElementById("xid").value = xid;
		    document.getElementById("eci").value = eci;
		    document.getElementById("cavv").value = cavv;
            document.getElementById("gid").value = gid;
            document.getElementById("formGompayRequest").submit();
			document.getElementById("msOrderBtnA").visiblity="visible";
		}
	}
	popupGompay3DS = null;
}

function doGompay3DSClose(){
  iframeGompay3DS = null;
  document.getElementById("divGompay3DS").style.display = "none";
}