Ext.onReady(function () {
    tazapay.config.connector_url = OfficeConfig.actionUrl;

    var grid = new tazapay.panel.Home();
    grid.render('office-tazapay-wrapper');

    var preloader = document.getElementById('office-preloader');
    if (preloader) {
        preloader.parentNode.removeChild(preloader);
    }
});