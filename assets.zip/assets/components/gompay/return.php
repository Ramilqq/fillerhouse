<?php
/*-------------------------------------------------------------------------------------------------
FILE NAME	: return.php
AUTHOR		: GOM Inc Technical Support Team, support@gominc.com
DATE		: 2022-07-01

http:www.gompay.net
Copyright (c) 2013 GOMInc Co., Ltd. All Rights Reserved.
--------------------------------------------------------------------------------------------------*/
header("Content-Type: text/html; charset=utf-8");
session_cache_limiter('no-cache, must-revalidate');
header("Pragma: no-cache");
header("Cache: no-cache");
header("Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0");
header("Expires:Mon, 26 Jul 1997 05:00:00 GMT");

// echo '<pre>';print_r($_POST);echo '</pre>'; exit();




    define('MODX_API_MODE', true);
    require dirname(dirname(dirname(dirname(__FILE__)))) . '/index.php';
    $modx->log(modX::LOG_LEVEL_ERROR, '[miniShop2:Gompay] requst '. print_r($_POST,1));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>GOMPAY</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="Cache-control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="Mon, 26 Jul 1997 05:00:00 GMT">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
</head>
<body>
<form name="formGompay" id="formGompay" method="POST">
    <input type="hidden" name="status" id="status" value="<?php echo $_POST['status'];?>">
    <input type="hidden" name="xid" id="xid" value="<?php echo $_POST['xid'];?>">
    <input type="hidden" name="eci" id="eci" value="<?php echo $_POST['eci'];?>">
    <input type="hidden" name="cavv" id="cavv" value="<?php echo $_POST['cavv'];?>">
    <input type="hidden" name="error" id="error" value="<?php echo $_POST['error'];?>">
    <input type="hidden" name="errorDescription" id="errorDescription" value="<?php echo $_POST['errorDescription'];?>">
    <input type="hidden" name="errorDetail" id="errorDetail" value="<?php echo $_POST['errorDetail'];?>">
    <input type="hidden" name="gid" id="gid" value="<?php echo $_POST['gid'];?>">

</form>
<script type="text/javascript">
<!--
function doReturn() {
    var status = document.getElementById("status").value;
    var xid = document.getElementById("xid").value;
    var eci = document.getElementById("eci").value;
    var cavv = document.getElementById("cavv").value;
    var gid = document.getElementById("gid").value;
    checkErrorMessage();
    window.opener.doPayment(status, xid, eci, cavv, gid);
    self.close();
}

function checkErrorMessage(){
    var status = document.getElementById("status").value;
    var error = document.getElementById("error").value;
    var errorDescription = document.getElementById("errorDescription").value;
    var errorDetail = document.getElementById("errorDetail").value;
    if(status == "FAIL" && error != "" && errorDescription != ""){
        var message = error + " : " + errorDescription + "\r\n" + errorDetail;
        alert(message);
    }
}

try {
    doReturn();
} catch (e) {
    document.write(e);
    document.write("<br>");
    document.write(navigator.userAgent);
    alert(e);
}

-->
</script>
</body>
</html>
