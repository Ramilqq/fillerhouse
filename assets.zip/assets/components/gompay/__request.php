<?php
/*-------------------------------------------------------------------------------------------------
FILE NAME	: request.php
AUTHOR		: GOM Inc Technical Support Team, support@gominc.com
DATE		: 2022-07-01

http:www.gompay.net
Copyright (c) 2013 GOMInc Co., Ltd. All Rights Reserved.
--------------------------------------------------------------------------------------------------*/


define('MODX_API_MODE', true);
require dirname(dirname(dirname(dirname(__FILE__)))) . '/index.php';
if (!defined('MODX_CORE_PATH')) {
    exit('Core not found');
}
$modx->getService('error', 'error.modError');
$modx->setLogLevel(modX::LOG_LEVEL_ERROR);
$modx->setLogTarget('FILE');

$miniShop2 = $modx->getService('miniShop2');
$miniShop2->loadCustomClasses('payment');
if (!class_exists('gomPayPayment')) {
    exit('Error: could not load payment class "Payment".');
}
$order = $modx->newObject('msOrder');
$handler = new gomPayPayment($order);
$config = $handler->getConfig();
$GOMPAY_MERCHANT_PASSWORD = $config['GOMPAY_MERCHANT_PASSWORD'];
$GOMPAY_3DS_URL = $config['GOMPAY_3DS_URL'];

header("Content-Type: text/html; charset=utf-8");
session_cache_limiter('no-cache, must-revalidate');
header("Pragma: no-cache");
header("Cache: no-cache");
header("Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0");
header("Expires:Mon, 26 Jul 1997 05:00:00 GMT");

//require_once('constants.php');

$overflow = "overflow:hidden;";
// On mobile, overflow style is not applied.
if(isset($_SERVER['HTTP_USER_AGENT'])){
  $userAgent = strtolower($_SERVER['HTTP_USER_AGENT']);
  $arrMobile = array('mobile', 'iphone', 'ipod', 'android', 'blackberry','symbianos','sch-m\d=', 'windows ce', 'nokia', 'webos', 'opera mini', 'sonyericsson', 'samsung', 'opera mobi', 'iemobile', 'windows phone');
  foreach ($arrMobile as &$value) {
    if(stripos($userAgent, $value)){
        $overflow = "";
        break;
    }
  }
}

$timestamp = date('YmdHis');  // YYYYMMDDHH24MISS
$checksum = $_POST['merchant_id'].$_POST['order_id'].$_POST['amount'].$_POST['card_number'].$timestamp.$GOMPAY_MERCHANT_PASSWORD;
$checksum = hash( "SHA256",$checksum);

// $returnKey = hash( "SHA256",$_POST['merchant_id'].$timestamp.GOMPAY_MERCHANT_PASSWORD);

// echo '<pre>';print_r($_POST);echo '</pre>'; exit();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>GOMPAY</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta http-equiv="Cache-control" content="no-cache, no-store, must-revalidate">
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="Expires" content="Mon, 26 Jul 1997 05:00:00 GMT">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
  <style type='text/css'>
  html,body {height:100%; <?php echo $overflow;?>}
  body {margin:0; padding:0;}
  iframe {margin:0; padding:0; border:0; width:100%; height:100%;}
  </style>
</head>
<body scroll="no">
<form name="formGompayRequest" id="formGompayRequest" method="POST" action="<?php echo $GOMPAY_3DS_URL;?>">
  <input type="hidden" name="version" id="version" value="<?php echo $_POST['version'];?>">
  <input type="hidden" name="merchant_id" id="merchant_id" value="<?php echo $_POST['merchant_id'];?>">
  <input type="hidden" name="order_id" id="order_id" value="<?php echo $_POST['order_id'];?>">
  <input type="hidden" name="amount" id="amount" value="<?php echo $_POST['amount'];?>">
  <input type="hidden" name="card_number" id="card_number" value="<?php echo $_POST['card_number'];?>">
  <input type="hidden" name="expiry_month" id="expiry_month" value="<?php echo $_POST['expiry_month'];?>">
  <input type="hidden" name="expiry_year" id="expiry_year" value="<?php echo $_POST['expiry_year'];?>">
  <input type="hidden" name="currency_code" id="currency_code" value="<?php echo $_POST['currency_code'];?>">
  <input type="hidden" name="return_url" id="return_url" value="<?php echo $_POST['return_url'];?>">
  
  <input type="hidden" name="checksum" id="checksum" value="<?php echo $checksum;?>">

  <!-- <input type="hidden" name="returnkey" id="returnkey" value="<?php echo $returnKey;?>"> -->

</form>
<script type="text/javascript">
<!--
try {
  document.getElementById('formGompayRequest').submit();
} catch (e) {
  document.write(e);
  document.write("<br>");
  document.write(navigator.userAgent);
  alert(e);
}
-->
</script>
</body>
</html>
