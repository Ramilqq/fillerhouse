<?php

define('MODX_API_MODE', true);

require dirname(dirname(dirname(dirname(__FILE__)))) . '/index.php';

if (!defined('MODX_CORE_PATH')) {
    exit('Core not found');
}

$modx->getService('error', 'error.modError');
$modx->setLogLevel(modX::LOG_LEVEL_ERROR);
$modx->setLogTarget('FILE');

//if($_GET['action'] == 'continue'){
//    $modx->log(modX::LOG_LEVEL_ERROR, '[============================================================================================');
//    $modx->log(modX::LOG_LEVEL_ERROR, '[miniShop2:tazaPay] respons callback'. print_r($_REQUEST,1));
//    $modx->log(modX::LOG_LEVEL_ERROR, '[============================================================================================');
//}


//$path = MODX_CORE_PATH . 'components/tazapay/';
//$scriptProperties = ['core_path' => $path];

//if (!$tazapay = $modx->getService('tazaPay', '', $path.'model/', $scriptProperties)) {
//    exit('Error: could not load payment class "tazaPay".');
//}

$miniShop2 = $modx->getService('miniShop2');
$miniShop2->loadCustomClasses('payment');

if (!class_exists('gomPayPayment')) {
    exit('Error: could not load payment class "Payment".');
}

$order = $modx->newObject('msOrder');
$handler = new gomPayPayment($order);

$context = 'web';
$params = array();

if ($_GET['action'] == 'continue' && !empty($_GET['msorder']) && !empty($_GET['mscode'])) {
    if ($order = $modx->getObject('msOrder', (int)$_GET['msorder'])) {
        if ($_GET['mscode'] == $handler->getOrderHash($order)) {
            $response = $handler->send($order);
            if ($response['success'] && !empty($response['data']['redirect'])) {
                $redirect = $response['data']['redirect'];
            }
        }else{
            exit('Error when continuing order1');
        }
    }else{
        exit('Error when continuing order2');
    }
} elseif ($_GET['action'] == '3dsecure') {
    if ($order = $modx->getObject('msOrder', (int)$_GET['msorder'])) {
        if ($_GET['mscode'] == $handler->getOrderHash($order)) {
            $handler->sendGompay($order, $_REQUEST);
            $params['msorder'] = $order->get('id');
        }else{
            exit('Error when continuing order3');
        }
    }else{
        exit('Error when continuing order4');
    }
} elseif (empty($_REQUEST['action'])) {
    exit('Access denied');
}else{
    exit('Access denied');
}

if ($modx->context->key !== $context && !empty($context)) {
    $modx->switchContext($context);
}

$success = $cancel = $modx->getOption('site_url');
if ($id = 6) {
    $success = $modx->makeUrl($id, $context, $params, 'full');
}
if ($id = 6) {
    $cancel = $modx->makeUrl($id, $context, $params, 'full');
}

if (!$redirect){
    $redirect = $success;
}

$modx->sendRedirect($redirect);


