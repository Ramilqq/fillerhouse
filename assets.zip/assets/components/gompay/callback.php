<?php

//https://test.estaderma.com/assets/components/tazapay/callback.php?action=complate&msorder=891&mscode=aa66d11605753501cf68150bc1384461

define('MODX_API_MODE', true);

require dirname(dirname(dirname(dirname(__FILE__)))) . '/index.php';

if (!defined('MODX_CORE_PATH')) {
    exit('Core not found');
}

$modx->getService('error', 'error.modError');
$modx->setLogLevel(modX::LOG_LEVEL_ERROR);
$modx->setLogTarget('FILE');

//if($_GET['action'] == 'continue'){
//    $modx->log(modX::LOG_LEVEL_ERROR, '[============================================================================================');
    $modx->log(modX::LOG_LEVEL_ERROR, '[miniShop2:tazaPay] respons callback'. print_r($_REQUEST,1));
//    $modx->log(modX::LOG_LEVEL_ERROR, '[miniShop2:tazaPay] respons '. print_r($_POST,1));
//    $modx->log(modX::LOG_LEVEL_ERROR, '[miniShop2:tazaPay] respons callback'. print_r($_GET,1));
//    $modx->log(modX::LOG_LEVEL_ERROR, '[============================================================================================');
//}


//$path = MODX_CORE_PATH . 'components/tazapay/';
//$scriptProperties = ['core_path' => $path];

//if (!$tazapay = $modx->getService('tazaPay', '', $path.'model/', $scriptProperties)) {
//    exit('Error: could not load payment class "tazaPay".');
//}

$miniShop2 = $modx->getService('miniShop2');
$miniShop2->loadCustomClasses('payment');

if (!class_exists('tazaPayPayment')) {
    exit('Error: could not load payment class "Pay".');
}

$order = $modx->newObject('msOrder');
$handler = new tazaPayPayment($order);

$context = 'web';
$params = array();
//echo '<pre>'. print_r($handler->getConfig(),1) . '</pre>';


if (isset($_GET['action']) && !empty($_GET['msorder']) && !empty($_GET['mscode'])) {

    if ($_GET['action'] == 'return'){
        if ($order = $modx->getObject('msOrder', (int)$_GET['msorder'])) {
            if ($_GET['mscode'] == $handler->getOrderHash($order)) {
                $responce = $_GET;
                return $handler->receive($order, $responce);
            }else{
                exit('Error when continuing order');
            }
        }else{
            exit('Error when continuing order');
        }
    }else{
        if ($order = $modx->getObject('msOrder', (int)$_GET['msorder'])) {
            if ($_GET['mscode'] == $handler->getOrderHash($order)) {
                $responce = $_GET;
                //$handler->receive($order, $responce);
                $url = $handler->getPaymentLink($order);
                $context = $order->get('context');
                $params['msorder'] = $order->get('id');
                //$params['mscode'] = hash('md5', $_REQUEST['mscode']);
            }else{
                exit('Error when continuing order');
            }
        }else{
            exit('Error when continuing order');
        }
    }
} elseif (empty($_REQUEST['action'])) {
    exit('Access denied');
}else{
    echo 'no';
}

if ($modx->context->key !== $context && !empty($context)) {
    $modx->switchContext($context);
}

$success = $cancel = $modx->getOption('site_url');
if ($id = 487) {
    $success = $modx->makeUrl($id, $context, $params, 'full');
}
if ($id = 487) {
    $cancel = $modx->makeUrl($id, $context, $params, 'full');
}

$redirect = !empty($_REQUEST['action']) && (!$url)
    ? $success
    : $url;
$modx->sendRedirect($redirect);


