<?php

if (!class_exists('msPaymentInterface')) {
    require_once MODX_CORE_PATH.'components/minishop2/model/minishop2/mspaymenthandler.class.php';
}

//

class gomPayPayment extends msPaymentHandler implements msPaymentInterface

{
    private $transactionKey;
    
    public $modx;
    public $gompay;
    
    function __construct(xPDOObject $object, $config = array())
    {
        parent::__construct($object, $config);
        
        $corePath = MODX_CORE_PATH . 'components/gompay/';
        $siteUrl = $this->modx->getOption('site_url');
        $assetsUrl = $this->modx->getOption('assets_url') . 'components/gompay/';
        $callbackUrl = $siteUrl . substr($assetsUrl, 1) . 'callback.php';
        $paymentUrl = $siteUrl . substr($assetsUrl, 1) . 'payment.php';
        $returnUrl = $siteUrl . substr($assetsUrl, 1) . 'payment.php';
        $gompayPaymentForm = $siteUrl.'/payment';
        
        $assetsTazapayUrl = $this->modx->getOption('assets_url') . 'components/tazapay/';
        $tazapayUrl = $siteUrl . substr($assetsTazapayUrl, 1) . 'payment.php';
        
        $this->config = array_merge([
            'modelPath' => $corePath . 'model/',
            
            'return_url' => $returnUrl,
            'tazapayUrl'=>$tazapayUrl,
            
            'callbackUrl' => $callbackUrl,
            'paymentUrl' => $paymentUrl,
            'gompayPaymentForm' => $gompayPaymentForm,
            'type_payment' => 4,
            'check_billing_address' => '1',
            'GOMPAY_3DS_URL' => 'https://gpgs.gompay.net/3ds2/request/',
            'GOMPAY_PAYMENT_URL' => 'https://gpgs.gompay.net/service/gateway/',
            'GOMPAY_MERCHANT_ID' => '21000011',
            'GOMPAY_MERCHANT_PASSWORD' => 'DC109DFA30B94DA',
            'GOMPAY_CURRENCY_CODE' => 'USD',
            'GOMPAY_CURRENCY_NUMBER' => '840',
            'version' => '1',
            'live' => '2', //1 test, 2 live
            'versionSecure' =>'1',
            'versionPayment' =>'1.9',

        ], $config);

        //if (!$this->gompay = $this->modx->getService('gompay', '', $this->config['modelPath'], [])) {
        //     return;
        //}
    }
    
    public function getConfig()
    {
        return $this->config;
    }
    
    public function send(msOrder $order)
    {   
        if ($order->get('status') == 2) {
            return $this->error('ms2_err_status_wrong');
        }
        $link = $this->setPaymentLink($order);
        return $this->success('', ['redirect' => $link]);
    }
    
    public function sendGompay(msOrder $order, $params)
    {   
        if ($order->get('status') == 2) {
            return $this->success('', array('msorder' => $order->get('id')));
        }
        
        $params = $this->params($params, $order);
        $params['validation'] = $this->validation();
        $this->setTransactionKey($params['validation'],
                                  $params['merchant_id'],
                                  $params['merchant_password'],
                                  $params['amount'],
                                  $params['order_id']);
        $params['transaction_key'] = $this->transactionKey;
        
        $this->modx->log(modX::LOG_LEVEL_ERROR, '[miniShop2:Gompay v2] test params: ' . print_r($params ,1));
        
        $response = $this->request($this->config['GOMPAY_PAYMENT_URL'], $params);
        
        $this->modx->log(modX::LOG_LEVEL_ERROR, '[miniShop2:Gompay v2] response: ' . print_r($response['result'] ,1));
        
        if ($response === null) {
            return false;
        }
        if ($response['result'] === false) {
            return false;
        }
        
        $arrResponse = $this->pase($response['result']);
        
        $this->modx->log(modX::LOG_LEVEL_ERROR, '[miniShop2:Gompay v2] arrResponse: ' . print_r($arrResponse ,1));
        
        if ($arrResponse['response']['result'] == 1000){
            $this->ms2->changeOrderStatus($order->get('id'), 2);
        }
        if ($msg = $arrResponse['response']['message']) {
            $order->set('comment', $msg);
            $order->save();
        }
        return $this->success('', array('msorder' => $order->get('id')));
    }
    
    public function receive(msOrder $order, $params = [])
    {
        return true;
    }
    
    public function getPaymentLink(msOrder $order)
    {
        
        /*return $this->config['tazapayUrl'] . '?' .
        http_build_query(array(
            'action' => 'continue',
            'msorder' => $order->get('id'),
            'mscode' => $this->getOrderHash($order),
        ));*/
        
        
        $params = http_build_query([
            'action' => 'continue',
            'mscode' => $this->getOrderHash($order),
            'msorder' => $order->get('id')
        ]);
        return $this->config['paymentUrl'] . '?' . $params;
    }
    
    public function setPaymentLink(msOrder $order)
    {   
        return $this->config['gompayPaymentForm'] . '?' .
        http_build_query(array(
            'action' => 'payment',
            'msorder' => $order->get('id'),
            'mscode' => $this->getOrderHash($order),
        ));
    }

    public function validation(){
        return rand(1,5);
    }

    public function setTransactionKey($validation,$merchantId,$merchantPassword,$amount,$orderId){
        switch ($validation)
        {
            case 1:
                $this->transactionKey = "merchant_id=".$merchantId."&merchant_password=".$merchantPassword."&amount=".$amount."&order_id=".$orderId;
                break;
            case 2:
                $this->transactionKey = "merchant_password=".$merchantPassword."&merchant_id=".$merchantId."&amount=".$amount."&order_id=".$orderId;
                break;
            case 3:
                $this->transactionKey = "order_id=".$orderId."&merchant_id=".$merchantId."&merchant_password=".$merchantPassword."&amount=".$amount;
                break;
            case 4:
                $this->transactionKey = "merchant_id=".$merchantId."&order_id=".$orderId."&amount=".$amount."&merchant_password=".$merchantPassword;
                break;
            case 5:
                $this->transactionKey = "order_id=".$orderId."&amount=".$amount."&merchant_id=".$merchantId."&merchant_password=".$merchantPassword;
                break;
            default:
                $this->transactionKey = "";
        }
        if($this->transactionKey!=""){
            $this->transactionKey = hash("sha256",$this->transactionKey);
        }
    }

    public function getTransactionKey(){
        return $this->transactionKey;
    }

    public function compare($key){
        if($key===$this->transactionKey){
            return true;
        }else{
            return false;
        }
    }

    public function request ($url, $param){
        $arrResult = array(
            'result' => false
            ,'http_code' => 0
            ,'error' => array(
                'code' => 0
                ,'message' => ''
            )
        );

        $curl = curl_init();

        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_VERBOSE, 1);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($curl, CURLOPT_FRESH_CONNECT, 1);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLINFO_HEADER_OUT, 0);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $param);

        $arrResult['result'] = curl_exec($curl);

        if ($arrResult['result'] === false || curl_errno($curl) != 0) {
            $arrResult['error']['code'] = curl_errno ($curl);
            $arrResult['error']['message'] = curl_error ($curl);
        }

        $arrResult['http_code'] = curl_getinfo ($curl)['http_code'];

        if ($arrResult['http_code'] !==200 ) {

            if($arrResult['error']['code'] == 0) {
                $arrResult['error']['code'] = $arrResult['http_code'];
                $arrResult['error']['message'] = ' CURL Error. HTTP CODE : ' . $arrResult['http_code'];
            } else {
                $arrResult['error']['code'] .= $arrResult['http_code'];
                $arrResult['error']['message'] .= ' CURL Error. HTTP CODE : ' . $arrResult['http_code'];
            }

            $arrResult['result']	= false;
        }

        curl_close($curl);

        return $arrResult;
    }

    public function pase ($xmlstr_) {

      $xml   = simplexml_load_string($xmlstr_, 'SimpleXMLElement', LIBXML_NOCDATA);
      $array = json_decode(json_encode($xml), TRUE);
      return $array;

    }
    
    public function params ($params, $order) {
        $prodArr = [];
        
        if ($products = $order->getMany('Products'))
        {
            foreach ($products as $item) {
                $name = $item->get('pagetitle');
                if (empty($name) && $product = $item->getOne('Product')) {
                    $name = $product->get('pagetitle');
                }
                $prodArr[] = $name;
                $i++;
            }
        }
        else
        {
            $prodArr[] = 'Non';
        }
        
        $profil = $order->getOne('UserProfile');
        $address = $order->getOne('Address');
        
        $fullname = $profil->get('fullname');
        $email = $profil->get('email');
        $mobilephone = $profil->get('mobilephone');
        
        $phone =  $address->get('phone');
        $receiver =  $address->get('receiver');
        $index =  $address->get('index');
        $country =  $address->get('country');
        $region =  $address->get('region');
        $city =  $address->get('city');
        $street =  $address->get('street');
        $building =  $address->get('building');
        $room =  $address->get('room');

        $array = array(
            'version'               => $this->config['version']
            ,'live'                 => $this->config['live']                        //1:test, 2:live
            ,'transaction_type'     => $this->config['type_payment']                //1:apporval 4: acquiring
            ,'merchant_id'          => $this->config['GOMPAY_MERCHANT_ID']          //Merchant ID
            ,'merchant_password'    => $this->config['GOMPAY_MERCHANT_PASSWORD']    //Merchant Transaction Password
            
            ,'order_id'             => $order->get('num')                           //Merchant Order ID
            ,'product_name'         => implode(',', $prodArr)                       //Product Name
            
            ,'amount'			    => $order->get('cost')                          //Amount of Payment Request
            ,'currency_number'      => $this->config['GOMPAY_CURRENCY_NUMBER']      //Transaction Currency Number (ISO 4217)
            ,'currency_code'        => $this->config['GOMPAY_CURRENCY_CODE']        //Transaction Currency Code (ISO 4217)
            
            ,'card_number'          => $params['card_number']                       //Card Number
            ,'expiry_month'         => $params['expiry_month']                      //Card Expiry Month 2 Digits
            ,'expiry_year'		    => $params['expiry_year']                       //Card Expiry Year 4 Digits
            
            ,'card_holder'          => $params['card_holder']                       //Name of the Card Holder
            ,'card_cvv'             => $params['card_cvv']                          //Card CVV 3 Digits
            
            ,'check_billing_address'=> $this->config['check_billing_address']       //Check Billing Information, 0: uncheck, 1:check
            ,'billing_first_name'	=> $receiver                                    //Billing First Name
            ,'billing_last_name'	=> $receiver                                    //Billing Last Name
            ,'billing_address'		=> $building                                    //Billing Address
            ,'billing_city'		    => $city                                        //Billing City
            ,'billing_state'        => $street                                      //Billing State
            ,'billing_zip'		    => $index                                       //Billing Zip
            ,'billing_country'		=> $region                                      //Billing Country / Nation (ISO 3166-1)
            ,'billing_email'		=> $email                                       //Billing Email
            
            
            ,'user_token_id'        => $order->get('user_id')                       //Merchant member ID, if no, process same as order number
            ,'client_ip'            => $_SERVER['REMOTE_ADDR']                      //Client’s IP address
            
            ,'3dsecure'             => 2                                            //3D SECURE (1:Non-Authentication, 2:Authentication)
            ,'cavv'                 => $params['cavv']                              //3D SECURE cavv (Cardholder Authentication Verification Value)
            ,'xid'                  => $params['xid']                               //3D SECURE xid (3D SECURE  Transaction ID)
            ,'eci'                  => $params['eci']                               //3D SECURE eci (Electronic Commerce Indicator)
            ,'gid'                  => $params['gid']
            ,'validation'           => ''
            ,'transaction_key'      => ''
        );
        return $array;
    }
}
