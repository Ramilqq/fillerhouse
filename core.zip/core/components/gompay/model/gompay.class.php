<?php

class gomPay
{
    /** @var modX $modx */
    public $modx;


    /**
     * @param modX $modx
     * @param array $config
     */
    //function __construct(modX &$modx, array $config = [])
    //{
    //    $this->modx =& $modx;
    function __construct(xPDOObject $object, $config = array())
    {
        parent::__construct($object, $config);
        $corePath = MODX_CORE_PATH . 'components/gompay/';
        $assetsUrl = MODX_ASSETS_URL . 'components/gompay/';

        $this->config = array_merge([
            'corePath' => $corePath,
            'modelPath' => $corePath . 'model/',
            'processorsPath' => $corePath . 'processors/',

            'connectorUrl' => $assetsUrl . 'connector.php',
            'assetsUrl' => $assetsUrl,
            'cssUrl' => $assetsUrl . 'css/',
            'jsUrl' => $assetsUrl . 'js/',
        ], $config);

        $this->modx->addPackage('gompay', $this->config['modelPath']);
        $this->modx->lexicon->load('gompay:default');
    }
    
    public function test(){
        return 'TEST';
    }
    
    public function createUser($params = []){
        /*
        params
        user_id, gompay_id, role
        */
        if(!$params){
            return false;
        }
        $user = $this->modx->newObject('tazaPayUser', $params);
        if(!$user){
            return false;
        }
        $user->save();
        return $user;
    }
    
    public function getUser($user_id){
        $user = $this->modx->getObject('tazaPayUser', ['user_id' => $user_id]);
        if(!$user){
            return false;
        }
        return $user;
    }
    
    public function createItem($params = []){
        /*
        params
        user_id, order_id, data, txn_no
        create_dt
        */
        if(!$params){
            return false;
        }
        $params = array_merge($params, ['create_dt' => date('Y-m-d H:i:s')]);
        $item = $this->modx->newObject('tazaPayItem', $params);
        if(!$item){
            return false;
        }
        $item->save();
        return true;
    }
    
    public function getItem($order_id){
        if(!$order_id){
            return [];
        }
        if(!$item = $this->modx->getObject('tazaPayItem', ['order_id' => $order_id])){
            return [];
        }
        return $item;
    }
    
    public function getItems($params = []){
        /*
        params
        user_id, order_id, data, txn_no, create_dt
        */
        if(!$params){
            return [];
        }
        if(!$items = $this->modx->getCollection('tazaPayItem', $params)){
            return [];
        }
        return $items;
    }
    
    public function testResponseEscrow(){
        $response = '{"status":"success","message":"escrow created successfully","data":{"txn_no":"2206-939006","state":"Escrow_Awaiting_Funds","sub_state":"na","txn_type":"goods","invoice_currency":"USD","invoice_amount":10,"fee_tier":"standard","fee_paid_by":"buyer","fee_tier_percentage":1.8,"fee_amount":0.18,"collect_amount":10,"disburse_amount":9.82,"transcation_source":"api"}}';
        return json_decode($response, true);
    }
    
    public function testResponseUser(){
        $response =  '{"status":"success","message":"User created successfully","data":{"account_id":"a68be337-2666-47fa-b537-030bddb0d09b","customer_id":""}}';
        return json_decode($response, true);
    }
    
    public function log($msg){
        $this->modx->log(modX::LOG_LEVEL_ERROR, $msg);
    }
    
    public function getContactCode($telephone){
        return $telephone;
    }
    
    public function getContry($name){
        $country = [
        'India' =>'IN',
        'Singapore' =>'SG',
        'Malaysia'  =>'MY',
        'Vietnam'   =>'VN',
        'Thailand'  =>'TH',
        'United States' =>'US',
        'United Kingdom'    =>'GB',
        'Austria'   =>'AT',
        'Belgium'   =>'BE',
        'Bulgaria'  =>'BG',
        'Cyprus'    =>'CY',
        'Croatia'   =>'HR',
        'Czech Republic'    =>'CZ',
        'Denmark'   =>'DK',
        'Estonia'   =>'EE',
        'Finland'   =>'FI',
        'France'    =>'FR',
        'Germany'   =>'DE',
        'Greece'    =>'GR',
        'Hungary'   =>'HU',
        'Ireland'   =>'IE',
        'Italy' =>'IT',
        'Latvia'    =>'LV',
        'Lithuania' =>'LT',
        'Luxembourg'    =>'LU',
        'Malta' =>'MT',
        'Netherlands'   =>'NL',
        'Poland'    =>'PL',
        'Portugal'  =>'PT',
        'Romania'   =>'RO',
        'Slovenia'  =>'SI',
        'Slovakia'  =>'SK',
        'Spain' =>'ES',
        'Sweden'    =>'SE',
        'Norway'    =>'NO',
        'Liechtenstein' =>'LI',
        'Iceland'   =>'IS',
        'Switzerland'   =>'CH',
        'Monaco'    =>'MC',
        'United Arab Emirates'  =>'AE',
        'China' =>'CN',
        'Nigeria'   =>'NG',
        'Qatar' =>'QA',
        'Hong Kong' =>'HK',
        'Japan' =>'JP',
        'South Korea'   =>'KR',
        'Taiwan'    =>'TW',
        'Australia' =>'AU',
        'Indonesia' =>'ID',
        'Brunei'    =>'BN',
        'Philippines'   =>'PH',
        'Cambodia'  =>'KH',
        'Oman'  =>'OM',
        'Saudi Arabia'  =>'SA',
        'Sri Lanka' =>'LK',
        'Kuwait'    =>'KW',
        'Kenya' =>'KE',
        'Bangladesh'    =>'BD',
        'Jordan'    =>'JO',
        'Nepal' =>'NP',
        'South Africa'  =>'ZA',
        'Israel'    =>'IL',
        'Turkey'    =>'TR',
        'Macau' =>'MO',
        'Bahrain'   =>'BH',
        'Mexico'    =>'MX',
        'Algeria'   =>'DZ',
        'Argentina' =>'AR',
        'Puerto Rico'   =>'PR',
        'Colombia'  =>'CO',
        'Chile' =>'CL',
        'Peru'  =>'PE',
        'Brazil'    =>'BR',
        'Kazakhstan'    =>'KZ',
        'Kyrgyzstan'    =>'KG',
        'Uzbekistan'    =>'UZ',
        'Turkmenistan'  =>'TM',
        'Tanzania'  =>'TZ',
        'Mozambique'    =>'MZ',
        'Papua New Guinea'  =>'PG',
        'Ethiopia'  =>'ET',
        'Cameroon'  =>'CM',
        'Equatorial Guinea' =>'GQ',
        'Gambia'    =>'GM',
        'Seychelles'    =>'SC',
        'Maldives'  =>'MV',
        'Fiji'  =>'FJ',
        'Canada'    =>'CA',
        'Pakistan'  =>'PK',
        'Myanmar'   =>'MM',
        'Ghana' =>'GH',
        'Mauritius' =>'MU',
        'Panama'    =>'PA',
        'Egypt' =>'EG',
        'Uganda'    =>'UG',
        'New Zealand'   =>'NZ',
        'Botswana'  =>'BW',
        'Morocco'   =>'MA',
        'Burkina Faso'  =>'BF',
        'Ivory Coast'   =>'CI',
        'Madagascar'    =>'MG',
        'Gabon' =>'GA',
        'Albania'   =>'AL',
        'Armenia'   =>'AM',
        'Curaçao'   =>'CW',
        'Angola'    =>'AO',
        'Aruba' =>'AW',
        'Azerbaijan'    =>'AZ',
        'Bosnia and Herzegovina'    =>'BA',
        'Barbados'  =>'BB',
        'Burundi'   =>'BI',
        'Bermuda'   =>'BM',
        'Bahamas'   =>'BS',
        'Belize'    =>'BZ',
        'Costa Rica'    =>'CR',
        'Cape Verde'    =>'CV',
        'Djibouti'  =>'DJ',
        'Greenland' =>'GL',
        'Faroe Islands' =>'FO',
        'Dominican Republic'    =>'DO',
        'Falkland Islands'  =>'FK',
        'Georgia'   =>'GE',
        'Gibraltar' =>'GI',
        'Guatemala' =>'GT',
        'Guyana'    =>'GY',
        'Honduras'  =>'HN',
        'Haiti' =>'HT',
        'Jamaica'   =>'JM',
        'Comoros'   =>'KM',
        'Cayman Islands'    =>'KY',
        'Laos'  =>'LA',
        'Lebanon'   =>'LB',
        'Liberia'   =>'LR',
        'Lesotho'   =>'LS',
        'Moldova'   =>'MD',
        'Mongolia'  =>'MN',
        'Mauritania'    =>'MR',
        'Malawi'    =>'MW',
        'Namibia'   =>'NA',
        'Nicaragua' =>'NI',
        'Paraguay'  =>'PY',
        'Serbia'    =>'RS',
        'Solomon Islands'   =>'SB',
        'Saint Helena'  =>'SH',
        'Sierra Leone'  =>'SL',
        'Suriname'  =>'SR',
        'São Tomé and Príncipe' =>'ST',
        'Eswatini'  =>'SZ',
        'Tajikistan'    =>'TJ',
        'Tonga' =>'TO',
        'Trinidad and Tobago'   =>'TT',
        'Ukraine'   =>'UA',
        'Uruguay'   =>'UY',
        'Vanuatu'   =>'VU',
        'Samoa' =>'WS',
        'Chad'  =>'TD',
        'Anguilla'  =>'AI',
        'Antigua and Barbuda'   =>'AG',
        'Dominica'  =>'DM',
        'Grenada'   =>'GD',
        'Saint Kitts and Nevis' =>'KN',
        'Saint Lucia'   =>'LC',
        'Saint Vincent and the Grenadines'  =>'VC',
        'Benin' =>'BJ',
        'Guinea-Bissau' =>'GW',
        'Mali'  =>'ML',
        'Sint Maarten'  =>'SX',
        'Niger' =>'NE',
        'Senegal'   =>'SN',
        'Togo'  =>'TG',
        'New Caledonia' =>'NC',
        'French Polynesia'  =>'PF',
        'Wallis and Futuna' =>'WF',
        'Zambia'    =>'ZM',
        'Montserrat'    =>'MS',
        'Bolivia'   =>'BO'
        ];
        return $country[$name] ?: 'US';
    }

}