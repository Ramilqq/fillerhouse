<?php

/**
 * @package modextra
 */
class gomPayItem extends xPDOSimpleObject
{
}