<?php

/**
 * @package modextra
 */
class gomPayUser extends xPDOSimpleObject
{
}