<?php
$xpdo_meta_map['gomPayItem']= array (
  'package' => 'gomPay',
  'version' => '1.1',
  'table' => 'gompay_items',
  'extends' => 'xPDOSimpleObject',
  'tableMeta' => 
  array (
    'engine' => 'InnoDB',
  ),
  'fields' => 
  array (
    'user_id' => NULL,
    'order_id' => NULL,
    'data' => NULL,
    'txn_no' => NULL,
    'create_dt' => NULL,
  ),
  'fieldMeta' => 
  array (
    'user_id' => 
    array (
      'dbtype' => 'int',
      'precision' => '10',
      'phptype' => 'integer',
      'null' => true,
    ),
    'order_id' => 
    array (
      'dbtype' => 'int',
      'precision' => '10',
      'phptype' => 'integer',
      'null' => true,
    ),
    'data' => 
    array (
      'dbtype' => 'text',
      'phptype' => 'string',
      'null' => true,
    ),
    'txn_no' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '100',
      'phptype' => 'string',
      'null' => true,
    ),
    'create_dt' => 
    array (
      'dbtype' => 'timestamp',
      'phptype' => 'timestamp',
      'null' => true,
    ),
  ),
  'aggregates' => 
  array (
    'gomPayUser' => 
    array (
      'class' => 'gomPayUser',
      'local' => 'user_id',
      'foreign' => 'user_id',
      'cardinality' => 'many',
      'owner' => 'local',
    ),
  ),
);
