<?php
$xpdo_meta_map['gomPayUser']= array (
  'package' => 'gomPay',
  'version' => '1.1',
  'table' => 'gompay_users',
  'extends' => 'xPDOSimpleObject',
  'tableMeta' => 
  array (
    'engine' => 'InnoDB',
  ),
  'fields' => 
  array (
    'user_id' => NULL,
    'tazapay_id' => NULL,
    'role' => NULL,
  ),
  'fieldMeta' => 
  array (
    'user_id' => 
    array (
      'dbtype' => 'int',
      'precision' => '10',
      'phptype' => 'integer',
      'null' => true,
    ),
    'tazapay_id' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '100',
      'phptype' => 'string',
      'null' => true,
    ),
    'role' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '100',
      'phptype' => 'string',
      'null' => true,
    ),
  ),
  'aggregates' => 
  array (
    'tazaPayItem' => 
    array (
      'class' => 'gomPayItem',
      'local' => 'user_id',
      'foreign' => 'user_id',
      'cardinality' => 'one',
      'owner' => 'foreign',
    ),
  ),
);

