<?php
require_once (dirname(__DIR__) . '/tazapayuser.class.php');
class gomPayUser_mysql extends gomPayUser {}