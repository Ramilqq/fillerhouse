<?php
require_once (dirname(__DIR__) . '/tazapayitem.class.php');
class gomPayItem_mysql extends gomPayItem {}