<?php
/**
 * Russian permissions Lexicon Entries for modExtra
 *
 * @package modExtra
 * @subpackage lexicon
 */
$_lang['modextra_save'] = 'Permission for save/update data.';