<?php
/**
 * English permissions Lexicon Entries for modExtra
 *
 * @package modExtra
 * @subpackage lexicon
 */
$_lang['modextra_save'] = 'Разрешает создание/изменение данных.';