<?php

/**
 * The home manager controller for tazaPay.
 *
 */
class tazaPayHomeManagerController extends tazaPayManagerController
{
    /** @var tazaPay $tazaPay */
    public $tazaPay;


    /**
     *
     */
    public function initialize()
    {
        $this->tazaPay = $this->modx->getService('tazaPay', 'tazaPay', MODX_CORE_PATH . 'components/tazapay/model/');
        parent::initialize();
    }


    /**
     * @return array
     */
    public function getLanguageTopics()
    {
        return ['tazapay:default'];
    }


    /**
     * @return bool
     */
    public function checkPermissions()
    {
        return true;
    }


    /**
     * @return null|string
     */
    public function getPageTitle()
    {
        return $this->modx->lexicon('tazapay');
    }


    /**
     * @return void
     */
    public function loadCustomCssJs()
    {
        $this->addCss($this->tazaPay->config['cssUrl'] . 'mgr/main.css');
        $this->addJavascript($this->tazaPay->config['jsUrl'] . 'mgr/tazapay.js');
        $this->addJavascript($this->tazaPay->config['jsUrl'] . 'mgr/misc/utils.js');
        $this->addJavascript($this->tazaPay->config['jsUrl'] . 'mgr/misc/combo.js');
        $this->addJavascript($this->tazaPay->config['jsUrl'] . 'mgr/widgets/items.grid.js');
        $this->addJavascript($this->tazaPay->config['jsUrl'] . 'mgr/widgets/items.windows.js');
        $this->addJavascript($this->tazaPay->config['jsUrl'] . 'mgr/widgets/home.panel.js');
        $this->addJavascript($this->tazaPay->config['jsUrl'] . 'mgr/sections/home.js');

        $this->addHtml('<script type="text/javascript">
        tazaPay.config = ' . json_encode($this->tazaPay->config) . ';
        tazaPay.config.connector_url = "' . $this->tazaPay->config['connectorUrl'] . '";
        Ext.onReady(function() {MODx.load({ xtype: "tazapay-page-home"});});
        </script>');
    }


    /**
     * @return string
     */
    public function getTemplateFile()
    {
        $this->content .= '<div id="tazapay-panel-home-div"></div>';

        return '';
    }
}