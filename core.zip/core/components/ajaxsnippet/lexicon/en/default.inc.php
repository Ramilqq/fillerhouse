<?php

$_lang['ajaxsnippet'] = 'AjaxSnippet';

$_lang['as_trigger'] = 'Load content!';