<?php
require_once (dirname(dirname(__FILE__)) . '/cgcontextvalue.class.php');
class cgContextValue_mysql extends cgContextValue {}